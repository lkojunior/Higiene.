Sitio web educativo: Promover la Salud - Hábitos de Higiene
Incluye una página HTML y un QR para acceder a la versión online.